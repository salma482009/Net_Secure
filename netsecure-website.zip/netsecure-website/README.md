# Net Secure – Smart Network Security System (demo website)

A complete static website (one file: `index.html`). No server, no database, no paid service, no keys.
Open it in any browser. Works on phone, tablet and desktop. English + Arabic (RTL).

## What is real and what is simulated
- Simulated: all devices, alerts, IDS/IPS events, AI detections, firewall hits, topology data.
- Demo only: Quarantine / Release change this dashboard and the audit log. They do NOT isolate any real device.
- Cisco Integration page shows "Not connected: Demo Mode". Real isolation needs an authorised backend connected to the network.
- Your edits are saved in the browser only (localStorage). "Reset demo data" is in the sidebar.

## Publish for free: GitHub Pages (works from a phone browser)
1. Unzip this file so you can see `index.html`.
2. Create a free account at github.com and sign in.
3. Tap + then "New repository". Name it `netsecure`, keep it Public, tap "Create repository".
4. Tap "uploading an existing file", choose `index.html`, tap "Commit changes".
5. Tap Settings, then Pages. Under "Branch" choose `main` and `/ (root)`, tap Save.
6. Wait 1 to 2 minutes. Your link is `https://YOUR-USERNAME.github.io/netsecure/`.

## Alternative: Netlify Drop
1. Go to https://app.netlify.com/drop and sign in (free).
2. Drag the folder that contains `index.html` onto the page.
3. Netlify gives you a public link immediately.

## QR code
After you have your public link, paste it into any free QR generator (for example https://www.qrcode-monkey.com) and download the image.

## Connecting the real Cisco network later (not done yet)
Packet Tracer -> syslog/SNMP -> collector service -> authenticated API -> this dashboard.
See the "Cisco Integration" page for the Cisco IOS commands (VLANs, port security, logging, quarantine ACL).
